  var logging = false;
  
  function init()
  {
	var firstDay = getItem("firstDay");
	if(firstDay == "0")
	{
		document.getElementById("firstday0").checked = true;
	}
	else
	{
		document.getElementById("firstday1").checked = true;
	}
	
	var showweek = getItem("showWeek");
	if(showweek == "0")
	{
		document.getElementById("showweek0").checked = true;
	}
	else
	{
		document.getElementById("showweek1").checked = true;
	}
	
  }
  
  function setFirstDay(value)
  {
  	setItem("firstDay", value);
  }
  
  function setWeek(value)
  {
  	setItem("showWeek", value);
  }
  
  
  function log(txt) {
    if(logging) {
      console.log(txt);
    }
  }
  
