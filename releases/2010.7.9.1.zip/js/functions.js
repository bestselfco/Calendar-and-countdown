var debug = true;

var now = new Date();
var currentYear = now.getFullYear();
var firstDayOfWeek = 1; //Default value
var daysInYear = 365;
var oldId = getItem("countto");
var selectorClass = "cal_day_chosen";
var normalClass = "cal_td_day";
var selectedClass = "."+"cal_day_chosen";



function init()
{
	if(debug) var start = new Date().getTime();
	
	showCal(currentYear);
	
	setCache();
	
	if(debug) var end = new Date().getTime();

	highLightSelectedDate();
	
	updateOnTime();
	
	log("Running time", (end-start));
	
	populateYearLinks();

}

function updateOnTime()
{
	setTimeDisplay();
	
	var t=setTimeout("updateOnTime()",1000); 
}

function setTimeDisplay()
{
	
}

function populateYearLinks()
{
	$("#yearLabel").html(currentYear);
	$("#ym6").html(currentYear-6);
	$("#ym1").html(currentYear-1);
	$("#ym2").html(currentYear-2);
	$("#ym3").html(currentYear-3);
	$("#ym4").html(currentYear-4);
	$("#ym5").html(currentYear-5);
	$("#yp1").html(currentYear+1);
	$("#yp2").html(currentYear+2);
	$("#yp3").html(currentYear+3);
	$("#yp4").html(currentYear+4);
	$("#yp5").html(currentYear+5);
	$("#yp6").html(currentYear+6);
	
}

function yearClicked(offset){
	log("linke");
	currentYear = currentYear + offset;
	showCal(currentYear);
}

function lastYear()
{
	currentYear--;
	showCal(currentYear);
	highLightSelectedDate();
	setCache();
	populateYearLinks();
	
}

function nextYear()
{
	currentYear++;
	showCal(currentYear);
	highLightSelectedDate();
	setCache();
	populateYearLinks();
	
}

function setCache(){
	//setItem(currentYear, $("#calendar").html());
}

//Keyboard controls
function keyPressed(key) {
	
	   	if(key == 37 || key == 40) { // down or right
            lastYear();
        }
        else if(key == 39 || key == 38) { // up or left
            nextYear();
        }
}

function log(cat, text)
{
	if(debug)
	{
		console.log(cat + ": " + text);
	}
}

//Highlights the chosen date, from loaded value
function highLightSelectedDate(){
	
	highlightDay(oldId);
	
}

function setBadge(text)
{
	text = text.toString();
	
	//if(text.length < 4)
	//{
		chrome.browserAction.setBadgeBackgroundColor({color:[24, 205, 50, 70]});
		chrome.browserAction.setBadgeText({text:text});
	//}
}

function setToolTip(text)
{
	text = text.toString();
	chrome.browserAction.setPopup({text:text});
}

function dayClicked(timestamp, force)
{
	oldId = getItem("countto");
		
	var idDate = new Date(timestamp+86400000);
	var diff = Math.abs(idDate.getDaysFromToday());
	
	if(oldId == timestamp)
	{
		//Unselect all
		removeHighLights();
		log("Same day", timestamp);
		setBadge("");
		setItem("countto", "null");
	}
	else
	{
		log("New day", timestamp);
		setItem("countto", timestamp);	
		setBadge(diff.toString());
		highlightDay(timestamp);
	}
	
	oldId = getItem("countto"); //Set the memory item as well
}


//Highlight a specific day, remove other hightlights
function highlightDay(timestamp)
{	
	var selectorNew = "#cal_day_"+timestamp;
	//Unselect all
	removeHighLights();
	$(selectorNew).removeClass(normalClass).addClass(selectorClass);
}

//Remove all highlights
function removeHighLights()
{
	$(selectedClass).addClass(normalClass).removeClass(selectorClass);
}

//Show a year.
function showCal(year)
{
	var showWeek = window.localStorage.getItem("showWeek");
	populateYear(year,"month"); //this year
	
	$("#yearLabel").html(year);
	
	if(showWeek != "1" && showWeek != "0"){
		showWeek = 1;
		window.localStorage.setItem("showWeek", 1);
	}
	
	
	
	if(showWeek == "0") $(".cal_weekblock").hide();
}