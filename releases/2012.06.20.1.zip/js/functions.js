var now = new Date(); //Today
var currentYear = now.getFullYear(); //This year
var firstDayOfWeek = 1; //Default value
var oldId = 0; //Get countdown value
var googleID = "caplfhpahpkhhckglldpmdmjclabckhc"; //For turning on/off logging
var extVersion = 0; //Get extension version - for logging

/**
 * Output to log if "debug" is true
 * 
 * @param cat Logging category
 * @param text Text to log
 */
function log(cat, text)
{
	if(location.hostname != googleID) //Only if local, not if proper
	{
		var time = new Date();
		console.log(time.getHours()+":"+time.getMinutes()+":"+time.getSeconds() + " " + cat + ": " + text);
	}
}

//Get countdown days
function getDistanceInDays()
{
	var tmpArray = JSON.parse(getItem("dateArray"));
	var countto = tmpArray[0];
	
	if(countto != null)
	{
		try {
			var badgeDate = new Date((countto*1)+86400000); //Stupid casting
			var diff = Math.abs(badgeDate.getDaysFromToday());

			if(badgeDate.getFullYear() > 1980 && badgeDate.getFullYear() < 2050)
			{
				return diff; //All is well;
			}
			else
			{
				return null; //Too large
			}
		}
		catch(err)
		{
			log(err);
			return null;
		}
	}
	else{
		return "";
	}
}

function googleTrackPageLoad()
{
	 var _gaq = _gaq || [];
     _gaq.push(['_setAccount', 'UA-21196533-2']);
     _gaq.push(['_trackPageview']);
   
     (function() {
       var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
       ga.src = 'https://ssl.google-analytics.com/ga.js';
       var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
     })();
     
     log("Google tracking page load");
     
}
