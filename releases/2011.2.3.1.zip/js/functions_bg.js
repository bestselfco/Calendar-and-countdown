function bginit()
{
	log("Init", "Background page init");
	resetSettings();
	maintain();
}

//Run periodic function
function maintain()
{
	updateBadgeFromStored();
	
	setToolTip(new Date().toLocaleDateString());
	
	//Maintain every second. That should be enough
	var t=setTimeout("maintain()", 10000);
	
}

function resetSettings()
{
	var badgeColor = getItem("badgeColor");

	if(badgeColor == null) {
		var color = "#18CD32";
		setItem("badgeColor", color);
		log("setting up default badge color");
	}
}

function updateBadgeFromStored()
{
	var countto = getItem("countto");
	 
	if(countto != null)
	{
		try {
			var badgeDate = new Date((countto*1)+86400000); //Stupid casting

			var diff = Math.abs(badgeDate.getDaysFromToday());
			
			if(badgeDate.getFullYear() > 1980 && badgeDate.getFullYear() < 2050)
			{
				setBadge(diff);
			}
		}
		catch(err)
		{
			
		}
	
	}
}

