function bginit()
{
	log("Init", "Background page init");
	maintain();
		
}

//Run periodic function
function maintain()
{
	log("Log", "Maintain()");
	updateBadgeFromStored();
	
	
	
	//Maintain every minute. That should be enough
	var t=setTimeout("maintain()", 60000);
	
}



function updateBadgeFromStored()
{
	var countto = getItem("countto");
	 
	if(countto != "null")
	{
		try {
			var badgeDate = new Date((countto*1)+86400000); //Stupid casting

			var diff = Math.abs(badgeDate.getDaysFromToday());
			
			if(badgeDate.getFullYear() > 1980 && badgeDate.getFullYear() < 2050)
			{
				setBadge(diff);
			}
		}
		catch(err)
		{
			
		}
	
	}
}

