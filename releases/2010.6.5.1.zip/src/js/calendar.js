function Calendar(year, month)
{
	log("Creating calendar", year+"-"+month);
		
	//Functions
	this.getCal = calGetCalMonFirst;
	
	//working vars
	this.stamps = [];
	this.month = month;
	this.workMonth = month-1;
	this.year = year;
	
	var date = new Date(year, this.workMonth, 1);
	var startPoint = date.getTime();
	

	//Make all date stamps
	for(var i = 1; i < 32; i++)
	{
	
		var tmpStampDate = new Date(year, this.workMonth, i);
		
		//Catch end of month
		if(i > 28)
		{
			if(tmpStampDate.getMonth() == this.workMonth){
			  // log("MonthOK", date.getMonth()+" "+this.workMonth);
			   this.stamps[i] = tmpStampDate.getTime();
			}
		}
		else
		{
			this.stamps[i] = tmpStampDate.getTime();
		}
		
	}
	
}

function showCal(year)
{
	var showWeek = window.localStorage.getItem("showWeek");
	populateYear(year,"month"); //this year
	
	$("#yearLabel").html(year);
	
	if(showWeek != "1" && showWeek != "0"){
		showWeek = 1;
		window.localStorage.setItem("showWeek", 1);
	}
	
	if(showWeek == "0") $(".cal_weekblock").hide();
}

function populateYear(year, selectstring)
{
	
	//Populate
	for(var i = 1; i < 13; i++)
	{
		var selectString = "#"+selectstring;
		if(i<10) selectString += "0";
		selectString += i;
		$(selectString).html(new Calendar(year,i).getCal());
	}
	
	//Add tool tips
	var days  = $(".cal_td_day");
	for(var i = 0; i < days.length; i++)
	{
		var id = $(days[i]).attr("id");
		$(days[i]).tooltip({ 
			effect: 'slide',
			offset:	[5, 0],
			predelay: 500,
			opacity: 1,
			layout: getToolTip(id)
		}).dynamic({ bottom: { direction: 'down', bounce: true } }); 
	}
	
}

function getToolTip(id)
{
	//Recreate date object
	var stampTmp = id.split('_');
	var stamp = parseInt(stampTmp[2]);
	var date = new Date(stamp+86400000);
	
	var moonphase = getLunarPhase(date);
	var day = date.getDay();
	var month = date.getMonth();
	var mDay = date.getDate();
	
	//Get correct suffix
	lDay = (mDay%10);
	switch(lDay)
	{
		case 1:
			if(mDay > 20 || mDay < 10) sFix = chrome.i18n.getMessage("numberSt");
			else sFix = chrome.i18n.getMessage("numberTh");
		break;
		case 2:
			if(mDay > 20 || mDay < 10) sFix = chrome.i18n.getMessage("numberNd");
			else sFix = chrome.i18n.getMessage("numberTh");
		break;
		case 3:
			if(mDay > 20 || mDay < 10) sFix = chrome.i18n.getMessage("numberRd");
			else sFix = chrome.i18n.getMessage("numberTh");
		break;
		default:
			sFix = chrome.i18n.getMessage("numberTh");
	}
	
	var monthName = chrome.i18n.getMessage("mon"+(month+1)); 
	
	var dateString = chrome.i18n.getMessage("fullDate", [ucFirst(chrome.i18n.getMessage("lday"+day)), monthName, mDay, sFix]);
	
	var out =  "<div>";
	out += "<span class='dayinfo'>"+dateString+"</span>";
	
	//Day of the year
	out += "<span class='dayinyear'>"+chrome.i18n.getMessage("dayCapital")+" "+date.getDayOfYear()+" / "+date.getDaysLeftInYear()+" "+chrome.i18n.getMessage("left")+".</span>";

	var fromToday = date.getDaysFromToday();
	
	out += "<span class='countdown'>";
	
	var suffix  = "";
	if(Math.abs(fromToday) != 1) suffix = chrome.i18n.getMessage("several_suffix"); //"s" if one
	
	if(fromToday < 0)
	{
		out += Math.abs(fromToday)+" "+chrome.i18n.getMessage("day", "test")+suffix+" "+chrome.i18n.getMessage("ago")+".";
	}
	else if(fromToday > 0)
	{
		out += fromToday+" "+chrome.i18n.getMessage("day")+suffix+" "+chrome.i18n.getMessage("leftuntil")+".";
	}
	
	out += "</span>";
	
	//Add moon image
	out += "<img class='moonicon' src='pics/phases/"+getLunarImage(moonphase)+"'>";
	out += "</div>";

	return out;
}



//Return the actual calendar html
function calGetCalMonFirst()
{

	var out = "<table class='cal'>";

	var firstDate = new Date(this.stamps[1]);
	
	var startWeek = firstDate.getWeek(1);
	var startWeekDay = firstDate.getDay();
	
	var tabWidth = 8;
	
	if(!this.showWeekNumber) tabWidth = 7;
	
	log("First date", firstDate.toDateString());
	log("First day", startWeekDay);
	
	var tmpWeek = startWeek;
	
	log("Start week", tmpWeek);

	var monthName = ucFirst(chrome.i18n.getMessage("mon"+(this.workMonth+1))); 
	
	out += "<tr class='cal_tr_header'><td class='cal_td_header' colspan = '8'>"+monthName+"</td></tr>"; //Month header
	
	
	
	//Day names
	out += "<tr class='cal_tr_titles'><td class='cal_td_weeknames cal_weekblock'>"+chrome.i18n.getMessage("weekHeader")+"</td>"; 
	out += "<td class='cal_td_dayname'>"+chrome.i18n.getMessage("sday1")+"</td>"; //Day names
	out += "<td class='cal_td_dayname'>"+chrome.i18n.getMessage("sday2")+"</td>"; //Day names
	out += "<td class='cal_td_dayname'>"+chrome.i18n.getMessage("sday3")+"</td>"; //Day names
	out += "<td class='cal_td_dayname'>"+chrome.i18n.getMessage("sday4")+"</td>"; //Day names
	out += "<td class='cal_td_dayname'>"+chrome.i18n.getMessage("sday5")+"</td>"; //Day name
	out += "<td class='cal_td_dayname'>"+chrome.i18n.getMessage("sday6")+"</td>"; //Day names
	out += "<td class='cal_td_dayname'>"+chrome.i18n.getMessage("sday0")+"</td></tr>"; //Day names

	out += "<tr class='cal_tr_dates'>";
	
//pad first
var days = 0; 

//Screw rules, hard code instead
switch(startWeekDay)
{
case 0:
	tmpWeek = tmpWeek - 1;
	if(tmpWeek == 0) tmpWeek = 52; //Will fail in some years
	out += "<td class='cal_td_weeknumber cal_weekblock'>"+tmpWeek+"</td>";
	out += "<td colspan=6>&nbsp;</td>";
	days = 6;
break;

case 1:
  	out += "<td class='cal_td_weeknumber cal_weekblock'>"+tmpWeek+"</td>";
  	//out += "<td colspan=6>&nbsp;</td>";
	days = 0;
break;
	
case 2:
  	out += "<td class='cal_td_weeknumber cal_weekblock'>"+tmpWeek+"</td>";
  	out += "<td colspan=1>&nbsp;</td>";
	days = 1;
 break;
 
 case 3:
  	out += "<td class='cal_td_weeknumber cal_weekblock'>"+tmpWeek+"</td>";
  	out += "<td colspan=2>&nbsp;</td>";
	days = 2;
 break;
 
 case 4:
  	out += "<td class='cal_td_weeknumber cal_weekblock'>"+tmpWeek+"</td>";
  	out += "<td colspan=3>&nbsp;</td>";
	days = 3;
 break;
 
 case 5:
  	out += "<td class='cal_td_weeknumber cal_weekblock'>"+tmpWeek+"</td>";
  	out += "<td colspan=4>&nbsp;</td>";
	days = 4;
 break;
 
case 6:
  	out += "<td class='cal_td_weeknumber cal_weekblock'>"+tmpWeek+"</td>";
  	out += "<td colspan=5>&nbsp;</td>";
	days = 5;
 break;
 
default:

  
}
	for(var i = 1; i < this.stamps.length; i++)
	{
		
		var tmpDate = new Date(this.stamps[i]);
		
		if(days==7)
		{	
			//log("week change", tmpDate.getWeek());
			tmpWeek = tmpDate.getWeek(1) ;
			
			//new row
			out += "</tr><tr class='cal_tr_dates'><td class='cal_td_weeknumber cal_weekblock'>"+tmpWeek+"</td>";
			days = 0;
		}
		
		var today = "";
		if(new Date().toDateString() == tmpDate.toDateString())
		{
			today = " cal_day_today";
		}
		
		out += "<td class='cal_td_day"+today+"' onclick='dayClicked("+this.stamps[i]+", false)' id='cal_day_"+this.stamps[i]+"' title=' '>"+tmpDate.getDate()+"</td>";
		days++;
	}
	
	out += "</tr>";
	
	out += "</table>";
	
	return ""+out;
}