
function bginit()
{
	
	resetSettings();
	maintain();
}

//Run periodic function
function maintain()
{
	updateBadgeFromStored();
	updatePopupFromStored();
	
	setToolTip(new Date().toLocaleDateString());
	
	//Maintain every second. That should be enough
	var t=setTimeout("maintain()", 60000);
	
}

function resetSettings()
{
	var badgeColor = getItem("badgeColor");

	if(badgeColor == null) {
		var color = "#18CD32";
		setItem("badgeColor", color);
		log("setting up default badge color");
	}
	
	var popup = getItem("popup");
	
	if(popup == null) {
		var popup = "12";
		setItem("popup", popup);
		log("setting up default popup");
	}
}



function updateBadgeFromStored()
{
	var countto = getItem("countto");
	 
	if(countto != null)
	{
		try {
			var badgeDate = new Date((countto*1)+86400000); //Stupid casting

			var diff = Math.abs(badgeDate.getDaysFromToday());
			
			if(badgeDate.getFullYear() > 1980 && badgeDate.getFullYear() < 2050)
			{
				setBadge(diff);
			}
		}
		catch(err)
		{
			
		}
	
	}
}

function updatePopupFromStored()
{
	var popup = getItem("popup");
	setPopup(popup);
}

//Listen for external stuff
chrome.extension.onRequest.addListener(
  function(request, sender, sendResponse) {
    if (request.action == "trackEvent") {
    
    	sendResponse({response: "ok"});
    	log("Google Analytics", request.event_type + ": "+request.event_details);
    	_gaq.push(['_trackEvent', request.event_type, request.event_details]);
    	
     }
     else if (request.action == "refresh") {
    
    	sendResponse({response: "ok"});
    	
    	log("Options event", "Refreshing settings");
    	
    	maintain();
    	
     }
    else
      sendResponse({}); // snub them.
  });

