$(document).ready(function() {
 googleTrack("page_viewed", "cal_12");
});