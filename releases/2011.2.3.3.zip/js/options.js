  var logging = false;
  
  function init()
  {
  	
  	//Setup tabs
	$(function() {
		// setup ul.tabs to work as tabs for each div directly under div.panes
		//$("ul.cstabs").tabs("div.css-panes > div", {effect: 'ajax'});
		$("ul.tabs").tabs("div.options > div");
	});
  
	var firstDay = getItem("firstDay");
	if(firstDay == "0")
	{
		document.getElementById("firstday0").checked = true;
	}
	else
	{
		document.getElementById("firstday1").checked = true;
	}
	
	var popup = getItem("popup");
	if(popup == "3")
	{
		document.getElementById("show31203").checked = true;
	}
	else
	{
		document.getElementById("show31212").checked = true;
	}
	
	var showweek = getItem("showWeek");
	if(showweek == "0")
	{
		document.getElementById("showweek0").checked = true;
	}
	else
	{
		document.getElementById("showweek1").checked = true;
	}
	
	$("#badgeColorSelect").val(getItem("badgeColor"));//;
	document.getElementById('badgeColorSelect').color.fromString(getItem("badgeColor"));
	
  }
  
  function setColor(where, hex)
  {
  
  		//Set color for selector element
  		$("#badgeColorSelect").css("color", hex);
  		
  		color = HexToRGB(hex);
  		
  		chrome.browserAction.setBadgeBackgroundColor({color:color});
  		setItem("badgeColor",hex);
  		//alert(color);
  }
  
  function setPopupFile(value)
  {
  	setItem("popup", value);
  }
  
  function setFirstDay(value)
  {
  	setItem("firstDay", value);
  }
  
  function setWeek(value)
  {
  	setItem("showWeek", value);
  }
  
  
  
  function log(txt) {
    if(logging) {
      console.log(txt);
    }
  }

