$(function() {

		var start = new Date().getTime();
	
		var datePickerOptions = new Object();
		
		//Set options
		datePickerOptions.numberOfMonths = [3,4];
		datePickerOptions.showOtherMonths = false;
		datePickerOptions.showWeek = true;
		datePickerOptions.showButtonPanel = false;
		datePickerOptions.hideIfNoPrevNext = true;
		datePickerOptions.firstDay = 1;
		datePickerOptions.minDate = new Date(2012, 0 , 1);
		datePickerOptions.maxDate = new Date(2013, 0 , 0);
		
		$( "#calendar" ).datepicker(datePickerOptions);
				
		//Test selector
		markdate(2012,5,6);
		markdate(2012,1,9);
		markdate(2012,11,30);
		
		loopAllDates();
		
		var end = new Date().getTime();
		var time = end - start;
		console.log('Execution time: ' + time + "ms");
		
	});

function markdate(year, month, day)
{
	var selectedCal;
	
	//Get correct month. Should be refactored to use index directly.
	$(".ui-datepicker-group").each(function(index, Element){
			if(index == month-1){
				selectedCal = Element;
			}
		});
	
	//Loop our way to correct day. Should be refactored to use index directly.
	$(selectedCal).children(".ui-datepicker-calendar").children("tbody").children("tr").children("td").children(".ui-state-default").each(function(index, Element){
		
		if(index == day-1)
		{
			$(Element).css("color", "red");
		}
		
	});
			
}

function loopAllDates()
{
	$(".ui-datepicker-group").children(".ui-datepicker-calendar").children("tbody").children("tr").children("td").children(".ui-state-default").each(function(index, Element){
		
		$(Element).attr("title", getToolTip(2012,index));
		
		var toolTipSettings = new Object();
		toolTipSettings.layout = "<div>index</div>";
		
		$(Element).tooltip({
			offset: [0,0]
		});
		
	});
	
}

function getToolTip(year, dayOfYear)
{
	var tooltip = "<div id='"+year+"_"+dayOfYear+"'>"+year+"_"+dayOfYear+"</div>";
	return tooltip;
}
